# Descent of Yomi — Press Kit

![logo](01_Logo/logo_white_transparent_1200x600.png)

> **Read your foe's stamina, parry the blow, and land the critical strike.**
> Deckbuilder × soulslike — a hardcore roguelike card battler where a single careless turn means death.

---

## Fact sheet

| | |
|---|---|
| **Title** | Descent of Yomi (Japanese title: 黄泉降り) |
| **Pronunciation** | The Japanese title 黄泉降り is read "Yomikudari"; "Descent of Yomi" is ディセント・オブ・ヨミ in Japanese |
| **Developer / Publisher** | R-each — a solo game developer |
| **Release date** | 27 July 2026 |
| **Platforms** | Windows (Steam) / iOS &amp; iPadOS 13.0+ (App Store) |
| **Steam App ID** | 4785610 |
| **Steam** | https://store.steampowered.com/app/4785610/ |
| **App Store** | https://apps.apple.com/jp/app/descent-of-yomi/id6788629303 |
| **Online press kit** | https://r-each0801.github.io/web/apps/descent-of-yomi-presskit.html |
| **Price** | Steam ¥655 JPY one-time (regional pricing applies) / iOS free — a ¥600 in-app purchase unlocks the whole game |
| **Free demo** | Yes — available on the Steam store page |
| **Genre** | Roguelike deckbuilder / Indie, RPG, Strategy |
| **Languages** | English, Japanese (full text localisation) |
| **Modes** | Single-player, Online PvP |
| **Steam features** | 13 Achievements, Steam Cloud, Family Sharing, Partial Controller Support, Keyboard-only / Mouse-only / Touch-only input options |
| **Website** | https://r-each0801.github.io/web/apps/descent-of-yomi.html |
| **Press contact** | reach.app.support@gmail.com |

---

## Descriptions — use as-is, or edit freely

**One line (23 words)**
A Japanese-folklore roguelike deckbuilder with soulslike tension — read your foe's stamina, break their guard, and turn back time when you fall.

**Short (50 words)**
Descent of Yomi is a roguelike deckbuilding card game set in the Japanese underworld. Stamina, not hit points, decides every duel: press the attack and your guard thins, hold back and you lose your edge. Parry, break the enemy's stamina, and drive the critical blow home before they do.

**Long**
Descent of Yomi is a roguelike deckbuilding card game about descending, ever deeper, through an underworld that reshapes itself with every run. Gather cards and relics, hone your deck, cut down the boss yokai that bar your way, and reach the deepest floor of the land of the dead.

Stamina is the heart of every duel. While your stamina holds, your body is hard to cut — yet every card you play burns stamina too. Read the enemy's moves, turn them aside with Parry, and the instant their stamina breaks, strike for the kill.

At the cursed Magatsu sites along the way, forbidden cards lie sleeping. Curse cards hold power enough to overturn any battle — but play one, and you can never be fully human again. Stack curses upon your soul to survive, or die untainted. That choice shapes how your journey ends.

---

## Key features

- **Branching maps that change every run** — no two descents are alike.
- **80+ yokai from Japanese folklore**, 190+ cards and relics.
- **7 Origins** with distinct playstyles, and unlocks that grow as you play.
- **Sakatoki** — cheat death once per run by turning back time to the moment before you fell.
- **Yokai Transformation** — curse cards win fights and cost you your humanity; the ending changes with how far you fall.
- **Karma** — six escalating difficulty tiers for players who clear the game.
- **Endless Descent** — beyond the final boss waits a bottomless mode with no floor.
- **Online PvP** — take your forged deck against decks built by other players.
- **Ink-and-blood artwork and a Japanese-instrument soundtrack**, all made by one person.

---

## Streaming, video and coverage policy

**You may monetise any video or stream of Descent of Yomi.** No permission or prior notice is needed.

- Let's Plays, reviews, guides, clips, shorts, thumbnails — all fine, on any platform.
- You may use every asset in this kit in your videos, thumbnails, articles and social posts.
- Spoilers are entirely at your discretion. Nothing is embargoed.
- Critical coverage is welcome. Please say what you actually think.
- The only requests: don't edit or recolour the logo, and don't present the game as endorsing a product or opinion it doesn't.

If you need footage or a screenshot that isn't in this kit, email **reach.app.support@gmail.com** and it will be arranged.

---

## What's in this kit

| Folder | Contents |
|---|---|
| `01_Logo/` | Title logo, transparent PNG. `logo_white_*` for dark backgrounds, `logo_ink_*` for light backgrounds. App icon at 64–1024 px plus `.ico`. `logo_on_keyart_*` is a ready-made key-visual with the logo placed. |
| `02_KeyArt_Capsules/` | Key art (3840×1240) and the Steam capsule set — main, header, vertical, library, small. |
| `03_Screenshots/Store_9_EN/` | The nine screenshots currently on the Steam store (English UI, with marketing captions burned in). |
| `03_Screenshots/Clean_16x9_JP/` | Thirteen caption-free 1920×1080 screenshots (Japanese UI) — use these when you want clean imagery. |
| `04_Trailer/` | The launch trailer, 1920×1080 / 60 fps / 39 s, in Japanese and English versions. |
| `05_Characters/` | Fifteen yokai illustrations as transparent PNG (1024×1024), for thumbnails and overlays. `characters.txt` lists their Japanese and English names. |
| `06_CardArt/` | Twelve card illustrations plus a contact sheet. `cards.txt` gives each card's name and effect in both languages. |

All images are unaltered game assets or unedited in-game captures.

---

## About the developer

**R-each** is one person. The programming, artwork, music, writing, English localisation and balance were all made by a single developer over the course of the project. Descent of Yomi is their first commercial title on Steam.

**Contact:** reach.app.support@gmail.com
**Store:** https://store.steampowered.com/app/4785610/
