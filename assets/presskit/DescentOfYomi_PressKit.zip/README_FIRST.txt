================================================================
  Descent of Yomi / 黄泉降り  —  Media Kit
  R-each (solo developer)   reach.app.support@gmail.com
  https://store.steampowered.com/app/4785610/
  Online press kit: https://r-each0801.github.io/web/apps/descent-of-yomi-presskit.html
================================================================

[EN]
Thank you for covering Descent of Yomi.

  * Open  index.html  in a browser to browse everything visually.
  * PressKit_EN.md  has the fact sheet, descriptions and asset list.

MONETISED VIDEO AND STREAMING IS PERMITTED. No permission needed,
no prior notice needed, no embargo, spoilers at your discretion.
Critical coverage is welcome — please say what you actually think.

Only two requests: please don't edit or recolour the logo, and
please don't present the game as endorsing something it doesn't.

Need a screenshot or a clip that isn't here?
Just email reach.app.support@gmail.com — it will be arranged.

[JA]
『黄泉降り』を取り上げてくださり、ありがとうございます。

  * index.html をブラウザで開くと、全素材を一覧できます。
  * PressKit_JA.md に基本情報・紹介文・収録物一覧があります。

収益化を含む配信・動画投稿は自由です。事前のご連絡も許諾も不要、
ネタバレ範囲もお任せ、伏せていただきたい箇所はありません。
辛口な評価も歓迎します。率直なご感想をお願いします。

お願いは2点だけです。ロゴの加工・色変更はご遠慮ください。
本作が特定の商品や主張を推奨しているかのような使い方もお控えください。

ここに無い映像・画像が必要でしたら
reach.app.support@gmail.com までお気軽にどうぞ。

----------------------------------------------------------------
  01_Logo/               Logo (transparent) + app icons
  02_KeyArt_Capsules/    Key art + Steam capsule set
  03_Screenshots/        Store_9_EN (captioned) / Clean_16x9_JP (clean)
  04_Trailer/            Launch trailer, JP and EN
  05_Characters/         15 yokai, transparent PNG 1024x1024
  06_CardArt/            12 card illustrations + contact sheet
----------------------------------------------------------------
